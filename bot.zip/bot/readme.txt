pip install python-telegram-bot
pip install python-telegram-bot --upgrade --force-reinstall
pip install psutil
pip install py-cpuinfo
pip install aiohttp
pip install pytz
pip install telegram 
